/*
* Fichero fuente.go 
*/

package main

import (
	"fmt"
	"golang.org/x/crypto/ssh"
	"io/ioutil"
	"net"
	//"strconv"
	"os"
	//"strings"
)


type SshClient struct {
	Config *ssh.ClientConfig
	Server string
}

//, privateKeyPassword string
func NewSshClient(user string, host string, port int, privateKeyPath string) (*SshClient, error) {
	// read private key file
	pemBytes, err := ioutil.ReadFile(privateKeyPath)
	
	if err != nil {
		return nil, fmt.Errorf("Reading private key file failed %v", err)
	}
	
	signer, err := ssh.ParsePrivateKey(pemBytes)
		if err != nil {
			return nil, fmt.Errorf("Parsing plain private key failed %v", err)
		}
	// build SSH client config
	config := &ssh.ClientConfig{
		User: user,
		Auth: []ssh.AuthMethod{
			ssh.PublicKeys(signer),
		},
		//HostKeyCallback: ssh.InsecureIgnoreHostKey(),
		HostKeyCallback: func(hostname string, remote net.Addr, key ssh.PublicKey) error {
			// use OpenSSH's known_hosts file if you care about host validation
			return nil
		},
	}
	client := &SshClient{
		Config: config,
		Server: fmt.Sprintf("%v:%v", host, port),
	}
	return client, nil
}

// Opens a new SSH connection and runs the specified command
// Returns the combined output of stdout and stderr
func (s *SshClient) RunCommand(cmd string) (string, error) {
	// open connection
	fmt.Println("Hola")
	conn, err := ssh.Dial("tcp", s.Server, s.Config)
	if err != nil {
		
		fmt.Println("Dial to ", s.Server," failed ", err)
		return s.Server,err
	}

	defer conn.Close()
	fmt.Println("El comando es ", cmd)

	// open session
	session, err := conn.NewSession()
	if err != nil {
		fmt.Errorf("Create session for %v failed %v", s.Server, err)
		return s.Server,err
	}

	defer session.Close()

	// run command and capture stdout/stderr
	output, err := session.CombinedOutput(cmd)

	return fmt.Sprintf("%s", output), err
}

func main(){
	
		//i,_ := strconv.Atoi(os.Args[2])
		//var info = strings.Split(os.Args[1],":")
		sshTCPServer, err := NewSshClient(
		"equipo", // Cliente
		"localhost", // Servidor
		22,
		"/home/equipo/.ssh/id_rsa") // Fichero con clave pública
		fmt.Println("Entra lanzar")

		if err != nil{
			fmt.Errorf("Hay un error")
		}
		output1,err := sshTCPServer.RunCommand("cd IngenieriaInformatica/QuintoSemestre/SistemasDistribuidos/practica3 && /usr/local/go/bin/go run worker.go " + os.Args[1])
		if err != nil{
			fmt.Errorf("Hay un error")
		}
	
		fmt.Println("La salida es",output1)
}
